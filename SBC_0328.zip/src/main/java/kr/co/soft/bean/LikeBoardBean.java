package kr.co.soft.bean;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LikeBoardBean {
	private String user_id; // VARCHAR(30) NOT NULL, /* user_id */
	private int board_num;// NUMBER N
}
