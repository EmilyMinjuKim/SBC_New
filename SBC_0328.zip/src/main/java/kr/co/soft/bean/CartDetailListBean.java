package kr.co.soft.bean;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartDetailListBean {
	
	private List<CartBean> cartList;

}
