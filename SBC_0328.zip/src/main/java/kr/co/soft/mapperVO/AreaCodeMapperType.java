package kr.co.soft.mapperVO;

public interface AreaCodeMapperType {

	String getCode();

	String getName();

}
