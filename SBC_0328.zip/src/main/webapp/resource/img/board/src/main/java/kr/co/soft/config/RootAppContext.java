package kr.co.soft.config;

import org.springframework.context.annotation.Configuration;

//프로젝트 작업시 등록 될 bean 을 정의하는 클래스(//<annotation-driven/>와 같음
@Configuration
public class RootAppContext {

}
